export interface Color {
    id: string;
    name: string;
}
