import {RecursoData} from './recurso-data.interface';

export interface Recurso {
    id: string;
    data: RecursoData;
}
