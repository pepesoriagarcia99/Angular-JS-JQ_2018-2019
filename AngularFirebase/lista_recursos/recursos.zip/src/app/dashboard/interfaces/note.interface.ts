import { NoteData } from './note-data.interface';

export interface Note {
    id: string;
    data: NoteData;
}
