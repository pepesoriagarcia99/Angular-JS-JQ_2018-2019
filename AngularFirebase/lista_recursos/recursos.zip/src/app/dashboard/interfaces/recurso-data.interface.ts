export interface RecursoData {
    autor: string;
    category: string;
    paginas: number;
    prestado: boolean;
}