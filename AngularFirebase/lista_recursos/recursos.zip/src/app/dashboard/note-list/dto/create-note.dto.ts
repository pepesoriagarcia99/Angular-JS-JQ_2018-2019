export class CreateNoteDto {
    category: string;
    color: string;
    content: string;
    title: string;
}
