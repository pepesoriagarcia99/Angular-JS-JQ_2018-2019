export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCnQepVZC1VpOmxVSvGHEbR5myyNqR11hg",
    authDomain: "biblioteca-001.firebaseapp.com",
    databaseURL: "https://biblioteca-001.firebaseio.com",
    projectId: "biblioteca-001",
    storageBucket: "biblioteca-001.appspot.com",
    messagingSenderId: "58687724660"
  }
};
